import java.util.Scanner;
public class wifiDiagnosis {

/*
* Class: CMSC203 
* Instructor:Prof. Grinburg
* Description: Wifi Diagnosis
* Due: 2/15/2021
* Platform/compiler: eclipse
* I pledge that I have completed the programming assignment independently.
  I have not copied the code from a student or any source.
  I have not given my code to any student.
  Print your Name here:Kidus Asafere
*/
public static void main(String[] args) {
Scanner scanner = new Scanner (System.in);
System.out.println("If you have a problem with internet connectivity, this WiFi Diagnosis might work.\n" + 
"\n" + 
"First step: reboot your computer\n");
System.out.println("Did that fix the problem?  (yes or no)");
String answer = scanner.next();
if (answer.equals("yes")) {
System.out.println("Rebooting your computer seemed to work");
}else {
System.out.println("Second step: reboot your router\n");
System.out.println("Did that fix the problem?  (yes or no)");
String answer2 = scanner.next();
if (answer2.equals("yes")) {
System.out.println("Rebooting your router seemed to work");
} else {
System.out.println("Third step: make sure the cables to your router are plugged in firmly and your router is getting power\n");;
System.out.println("Did that fix the problem? (yes or no)");
String answer3 = scanner.next();
if (answer3.equals("yes")) {
System.out.println("Checking the cables seemed to work");
} else {
System.out.println("Fourth step:move the computer closer to the router and try to connect\n");
System.out.println("Did that fix the problem?  (yes or no)");
String answer4 = scanner.next();
if (answer4.equals("yes")) {
System.out.println("Moving closer to the router worked");
} else {
System.out.println("Fifth Step: Contact your ISP\n");
System.out.println("Make sure your ISP is hooked up to your router.");
}
}
}
}
}
}





